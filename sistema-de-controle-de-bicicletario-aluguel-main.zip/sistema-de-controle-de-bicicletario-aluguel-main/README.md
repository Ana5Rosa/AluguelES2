# sistema de controle de bicicletário - aluguel

Este é um projeto acadêmico de Engenharia de Software focado na prática da arquitetura de Microsserviços. O projeto demonstra minhas competências iniciais em desenvolvimento Java utilizando o framework Javalin.

A base para este desenvolvimento é a especificação OpenAPI/Swagger (disponível em: https://app.swaggerhub.com/apis/pasemes/sistema-de_controle_de_bicicletario2/1), garantindo uma abordagem Design-First. O escopo inicial está concentrado na implementação completa do Microsserviço de Aluguel e seus respectivos endpoints RESTful.

